<?php
// Text
$_['text_subject']		= '%s - Позвънете обратно поръчка';
$_['text_waiting']		= 'Очакване за Позвъняване.';
$_['text_telephone']	= 'Телефон: %s';
$_['text_name']			= 'Име: %s';
$_['text_enquiry']		= 'Коментар: %s';
$_['text_calltime']		= 'Удобно време за разговор: %s';