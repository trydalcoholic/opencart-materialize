<?php
$_['text_view_map']	= 'Преглед на картата';