<?php
// Text
$_['text_sizechart']	= 'Таблиця розмірів';