<?php
// Text
$_['text_subject']		= '%s - Ringe Tilbage orden';
$_['text_waiting']		= 'Banke På.';
$_['text_telephone']	= 'Telefon: %s';
$_['text_name']			= 'Navn: %s';
$_['text_enquiry']		= 'Kommentar: %s';
$_['text_calltime']		= 'Bekvem tid for et opkald: %s';