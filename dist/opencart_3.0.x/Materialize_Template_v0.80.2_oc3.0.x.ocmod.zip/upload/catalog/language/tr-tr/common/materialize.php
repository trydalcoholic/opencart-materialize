<?php
$_['text_blog']				= 'Blog';
$_['text_contact']			= 'İletişime geçin';
$_['text_about']			= 'Hakkında';
$_['text_delivery']			= 'Teslimat';
$_['text_comparison_list']	= 'Ürünleri karşılaştır';
$_['text_shopping_cart']	= 'Alışveriş sepetiniz';
$_['text_cat_says']			= 'Biraz para harcamanıza yardım edeyim :)';
$_['text_product_removed']	= 'Öğe sepetten kaldırıldı';
$_['text_cancel']			= 'İptal etmek';