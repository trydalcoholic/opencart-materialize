<?php
// PhotoSwipe
$_['button_share']					= 'Share';
$_['button_pswp_close']				= 'Close (Esc)';
$_['button_pswp_toggle_fullscreen']	= 'Toggle fullscreen';
$_['button_pswp_zoom']				= 'Zoom in/out';
$_['button_pswp_prev']				= 'Previous (arrow left)';
$_['button_pswp_next']				= 'Next (arrow right)';