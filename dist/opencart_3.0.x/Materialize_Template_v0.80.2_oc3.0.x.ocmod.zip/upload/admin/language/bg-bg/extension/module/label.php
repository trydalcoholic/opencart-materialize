<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-tags"></i>&nbsp;&nbsp;&nbsp;Materialize "Етикети"</b></font>';
$_['label_title']		= 'Materialize "Етикети"';

// Text
$_['text_module']		= 'Модули';
$_['text_success']		= 'Настройките на модула са обновени!';
$_['text_edit']			= 'Редактиране на Materialize Етикети';

// Entry
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'Нямате разрешение да управлявате този модул!';