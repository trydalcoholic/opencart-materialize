<?php
// Heading
$_['heading_title']				= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Допълнителни полета</b></font>';
$_['additionalfields_title']	= 'Допълнителни полета';

// Text
$_['text_module']				= 'Модули';
$_['text_success']				= 'Настройките на модула бяха обновени!';
$_['text_edit']					= 'Редактиране на Допълнителните полета';

// Entry
$_['entry_status']				= 'Статус';

// Error
$_['error_permission']			= 'Нямате разрешение да управлявате този модул!';