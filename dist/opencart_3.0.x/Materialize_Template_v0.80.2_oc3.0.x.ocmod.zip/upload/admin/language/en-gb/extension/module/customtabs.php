<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Custom Tabs</b></font>';
$_['customtabs_title']	= 'Custom Tabs';

// Text
$_['text_module']		= 'Modules';
$_['text_success']		= 'Module settings updated!';
$_['text_edit']			= 'Editing Custom Tabs';

// Entry
$_['entry_status']		= 'Status';

// Error
$_['error_permission']	= 'You do not have permission to manage this module!';