<?php
// Text
$_['text_materialize']				= 'Materialize Skabelon';
$_['text_materialize_settings']		= 'Indstillinger';
$_['text_labels']					= 'Etiketter';
$_['text_sizechart']				= 'Størrelse Diagrammer';
$_['text_callback']					= '"Ringe Tilbage"';
$_['text_callback_dashboard']		= '"Ring Tilbage" Dashboard';
$_['text_callback_settings']		= '"Ring Tilbage"-Indstillinger';
$_['text_map']						= 'Kort';
$_['text_quickorder']				= 'Quickorder';
$_['text_blog']						= 'Blog';
$_['text_blog_category']			= 'Kategorier';
$_['text_blog_post']				= 'Indlæg';
$_['text_blog_author']				= 'Forfattere';
$_['text_blog_comment']				= 'Kommentarer';
$_['text_blog_settings']			= 'Blog-Indstillinger';
$_['text_apply']					= 'Anvend';
$_['text_customtab']				= 'Tilpasset Fane';
$_['text_add_tab']					= 'Tilføj Under Fanen';
$_['text_tab_title']				= 'Fanen Titel';
$_['text_additionalfield']			= 'Ekstra Felt';
$_['text_add_additionalfield']		= 'Tilføj Ekstra Felt';
$_['text_additionalfield_title']	= 'Ekstra Felt Titel';