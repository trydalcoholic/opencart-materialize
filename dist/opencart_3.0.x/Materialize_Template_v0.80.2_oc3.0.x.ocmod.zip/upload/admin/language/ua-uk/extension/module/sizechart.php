<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-table"></i>&nbsp;&nbsp;&nbsp;Materialize "Таблиця розмірів"</b></font>';
$_['sizechart_title']	= 'Materialize "Таблиця розмірів"';

// Text
$_['text_module']		= 'Модулі';
$_['text_success']		= 'Налаштування модуля оновлено!';
$_['text_edit']			= 'Редагування Materialize Таблиці розмірів';

// Status
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'У вас немає прав для управління модулем!';