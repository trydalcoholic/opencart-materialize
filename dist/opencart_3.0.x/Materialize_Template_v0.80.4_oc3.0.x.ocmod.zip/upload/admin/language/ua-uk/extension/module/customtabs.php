<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Додаткові вкладки</b></font>';
$_['customtabs_title']	= 'Додаткові вкладки';

// Text
$_['text_module']		= 'Модулі';
$_['text_success']		= 'Налаштування модуля оновлено!';
$_['text_edit']			= 'Редагування Додаткових вкладок';

// Entry
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'У вас немає прав для управління модулем!';