<?php
// Text
$_['text_materialize']				= 'Materialize Template';
$_['text_materialize_settings']		= 'Setări';
$_['text_labels']					= 'Etichete';
$_['text_sizechart']				= 'Mărimea graficelor';
$_['text_callback']					= 'Suna inapoi';
$_['text_callback_dashboard']		= 'Panou de apel';
$_['text_callback_settings']		= 'Setări apel înapoi';
$_['text_map']						= 'Hartă';
$_['text_quickorder']				= 'Comanda rapida';
$_['text_blog']						= 'Blog';
$_['text_blog_category']			= 'Categorii';
$_['text_blog_post']				= 'Posturi';
$_['text_blog_author']				= 'Autori';
$_['text_blog_comment']				= 'Comentarii';
$_['text_blog_settings']			= 'Setări blog';
$_['text_apply']					= 'Aplica';
$_['text_customtab']				= 'Fila personalizată';
$_['text_add_tab']					= 'Adăugați fila';
$_['text_tab_title']				= 'Titlul fila';
$_['text_additionalfield']			= 'Câmp suplimentar';
$_['text_add_additionalfield']		= 'Adăugați câmpul suplimentar';
$_['text_additionalfield_title']	= 'Titlu suplimentar de câmp';
$_['text_about_template']			= 'Informații despre șabloane';