<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-table"></i>&nbsp;&nbsp;&nbsp;Materialize "Size chart"</b></font>';
$_['sizechart_title']	= 'Materialize "Size chart"';

// Text
$_['text_module']		= 'Module';
$_['text_success']		= 'Setările modulelor au fost actualizate!';
$_['text_edit']			= 'Modificați modulul diagramă dimensiune';

// Entry
$_['entry_status']		= 'Status';

// Error
$_['error_permission']	= 'Nu aveți permisiunea de a gestiona acest modul!';