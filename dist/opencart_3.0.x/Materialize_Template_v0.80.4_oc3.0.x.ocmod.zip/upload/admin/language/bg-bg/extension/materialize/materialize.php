<?php
// Text
$_['text_materialize']				= 'Materialize Template';
$_['text_materialize_settings']		= 'Настройки';
$_['text_labels']					= 'Етикети';
$_['text_sizechart']				= 'Таблица Размери';
$_['text_callback']					= 'Позванете обратно';
$_['text_callback_dashboard']		= 'Табло Позванете обратно';
$_['text_callback_settings']		= 'Настройки Позванете обратно';
$_['text_map']						= 'Карта';
$_['text_quickorder']				= 'Бърза поръчка';
$_['text_blog']						= 'Блог';
$_['text_blog_category']			= 'Категории';
$_['text_blog_post']				= 'Публикации';
$_['text_blog_author']				= 'Автори';
$_['text_blog_comment']				= 'Коментари';
$_['text_blog_settings']			= 'Настройки Блог';
$_['text_apply']					= 'Приложете';
$_['text_customtab']				= 'Персонализиран Раздел';
$_['text_add_tab']					= 'Добави Раздел';
$_['text_tab_title']				= 'Заглавие на Раздела';
$_['text_additionalfield']			= 'Допълнително поле';
$_['text_add_additionalfield']		= 'Добави Допълнително поле';
$_['text_additionalfield_title']	= 'Заглавие на допълнителното поле';
$_['text_about_template']			= 'Информация за шаблона';