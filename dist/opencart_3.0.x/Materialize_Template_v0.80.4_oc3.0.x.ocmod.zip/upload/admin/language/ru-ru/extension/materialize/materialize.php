<?php
// Text
$_['text_materialize']				= 'Materialize Template';
$_['text_materialize_settings']		= 'Настройки';
$_['text_labels']					= 'Этикетки';
$_['text_sizechart']				= 'Таблицы размеров';
$_['text_callback']					= 'Обратный звонок';
$_['text_callback_dashboard']		= 'Панель Обратного звонка';
$_['text_callback_settings']		= 'Настройки Обратного звонка';
$_['text_map']						= 'Карта';
$_['text_quickorder']				= 'Быстрый заказ';
$_['text_blog']						= 'Блог';
$_['text_blog_category']			= 'Категории';
$_['text_blog_post']				= 'Посты';
$_['text_blog_author']				= 'Авторы';
$_['text_blog_comment']				= 'Комментарии';
$_['text_blog_settings']			= 'Настройки Блога';
$_['text_apply']					= 'Применить';
$_['text_customtab']				= 'Дополнительная вкладка';
$_['text_add_tab']					= 'Добавить вкладку';
$_['text_tab_title']				= 'Название вкладки';
$_['text_additionalfield']			= 'Дополнительное поле';
$_['text_add_additionalfield']		= 'Добавить Дополнительное поле';
$_['text_additionalfield_title']	= 'Название Дополнительного поля';
$_['text_about_template']			= 'Информация о шаблоне';