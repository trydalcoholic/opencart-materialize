<?php
// Text
$_['text_materialize']				= 'Materialize Template';
$_['text_materialize_settings']		= 'Ayarlar';
$_['text_labels']					= 'Etiketler';
$_['text_sizechart']				= 'Boyut Tabloları';
$_['text_callback']					= 'Geri arama';
$_['text_callback_dashboard']		= 'Paneli Geri arama';
$_['text_callback_settings']		= 'Geri Arama Ayarları';
$_['text_map']						= 'Harita';
$_['text_quickorder']				= 'Hızlı sipariş';
$_['text_blog']						= 'Blog';
$_['text_blog_category']			= 'Kategoriler';
$_['text_blog_post']				= 'Mesajlar';
$_['text_blog_author']				= 'Yazarlar';
$_['text_blog_comment']				= 'Yorumlar';
$_['text_blog_settings']			= 'Blog ayarları';
$_['text_apply']					= 'Uygula';
$_['text_customtab']				= 'Özel Sekme';
$_['text_add_tab']					= 'Sekme Ekle';
$_['text_tab_title']				= 'Sekme Başlığı';
$_['text_additionalfield']			= 'İlave Alan';
$_['text_add_additionalfield']		= 'Ek Alan Ekle';
$_['text_additionalfield_title']	= 'İlave Saha Başlığı';
$_['text_about_template']			= 'Şablon Bilgileri';