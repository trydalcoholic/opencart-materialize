<?php
// Heading
$_['heading_title']			= '<font color="#263238"><b><i class="fa fa-phone"></i>&nbsp;&nbsp;&nbsp;Materialize "Geri Arama"</b></font>';
$_['callback_title']		= 'Materialize "Geri Arama"';

// Text
$_['text_extension']		= 'Uzantıları';
$_['text_success']			= 'Başarı: Kontrol panelini değiştirdiniz "Geri Arama"!';
$_['text_edit']				= 'Kontrol Panelini Düzenle "Geri Arama"';
$_['text_view']				= 'Daha fazla göster...';

// Entry
$_['entry_status']			= 'Durum';
$_['entry_sort_order']		= 'Sıralama düzeni';
$_['entry_width']			= 'Genişlik';

// Error
$_['error_permission']		= 'Uyarı: Kontrol paneli "Geri Arama" modunu değiştirme izniniz yok!';