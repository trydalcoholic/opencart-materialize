<?php
// Heading
$_['heading_title']				= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;İlave Alanlar</b></font>';
$_['additionalfields_title']	= 'İlave Alanlar';

// Text
$_['text_module']				= 'Modüller';
$_['text_success']				= 'Modül ayarları güncellendi!';
$_['text_edit']					= 'Ek Alanların Düzenlenmesi';

// Entry
$_['entry_status']				= 'Durum';

// Error
$_['error_permission']			= 'Bu modül yönetmek için izniniz yok!';