<?php
// Text
$_['text_materialize']				= 'Materialize Template';
$_['text_materialize_settings']		= 'Settings';
$_['text_labels']					= 'Labels';
$_['text_sizechart']				= 'Size Charts';
$_['text_callback']					= 'Call Back';
$_['text_callback_dashboard']		= 'Call Back Dashboard';
$_['text_callback_settings']		= 'Call Back Settings';
$_['text_map']						= 'Map';
$_['text_quickorder']				= 'Quickorder';
$_['text_blog']						= 'Blog';
$_['text_blog_category']			= 'Categories';
$_['text_blog_post']				= 'Posts';
$_['text_blog_author']				= 'Authors';
$_['text_blog_comment']				= 'Comments';
$_['text_blog_settings']			= 'Blog Settings';
$_['text_apply']					= 'Apply';
$_['text_customtab']				= 'Custom Tab';
$_['text_add_tab']					= 'Add Tab';
$_['text_tab_title']				= 'Tab Title';
$_['text_additionalfield']			= 'Additional Field';
$_['text_add_additionalfield']		= 'Add Additional Field';
$_['text_additionalfield_title']	= 'Additional Field Title';
$_['text_about_template']			= 'Template Information';