<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-table"></i>&nbsp;&nbsp;&nbsp;Materialize "Size Chart"</b></font>';
$_['sizechart_title']	= 'Materialize "Size Chart"';

// Text
$_['text_module']		= 'Modules';
$_['text_success']		= 'Module settings updated!';
$_['text_edit']			= 'Editing Materialize Size Chart';

// Entry
$_['entry_status']		= 'Status';

// Error
$_['error_permission']	= 'You do not have permission to manage this module!';