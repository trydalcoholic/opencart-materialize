<?php
// Text
$_['text_subject']		= '%s - Geri arama sırası';
$_['text_waiting']		= 'Görüşme Beklemede.';
$_['text_telephone']	= 'Telefon: %s';
$_['text_name']			= 'İsim: %s';
$_['text_enquiry']		= 'Yorum Yap: %s';
$_['text_calltime']		= 'Bir görüşme yapmak için uygun zaman: %s';