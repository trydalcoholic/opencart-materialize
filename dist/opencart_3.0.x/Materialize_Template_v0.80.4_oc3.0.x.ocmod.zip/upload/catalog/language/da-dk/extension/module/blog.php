<?php
// Heading
$_['heading_search']	= 'Søg';
$_['heading_category']	= 'Kategorier';
$_['heading_post']		= 'Seneste Indlæg';

// Text
$_['text_search']		= 'Søg Blog';