<?php
// Text
$_['text_subject']		= '%s - Hurtig ordre';
$_['text_waiting']		= 'Venter på en hurtig rækkefølge.';
$_['text_product']		= 'Produkt: %s';
$_['text_link']			= 'Link: %s';
$_['text_telephone']	= 'Telefon: %s';
$_['text_name']			= 'Navn: %s';
$_['text_email']		= 'E-mail: %s';
$_['text_enquiry']		= 'Kommentar: %s';
$_['text_calltime']		= 'Bekvem tid for et opkald: %s';