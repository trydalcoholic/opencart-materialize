<?php
$_['text_view_map']	= 'Посмотреть на карте';