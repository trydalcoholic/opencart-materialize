<?php
// Text
$_['text_refine']		= 'Уточнить поиск';
$_['text_post']			= 'Посты';
$_['text_error']		= 'Категория не найдена!';
$_['text_empty']		= 'В этой категории нет публикаций.';
$_['text_sort']			= 'Сортировать';
$_['text_default']		= 'По умолчанию';
$_['text_name_asc']		= 'По имени (A - Я)';
$_['text_name_desc']	= 'По имени (Я - A)';
$_['text_limit']		= 'Показывать';
$_['text_read_more']	= 'Читать далее';
$_['text_author']		= 'Автор';
$_['text_published']	= 'Дата публикации';