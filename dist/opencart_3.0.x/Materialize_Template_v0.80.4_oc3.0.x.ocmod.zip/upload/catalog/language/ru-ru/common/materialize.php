<?php
$_['text_blog']				= 'Блог';
$_['text_contact']			= 'Контакты';
$_['text_about']			= 'О нас';
$_['text_delivery']			= 'Доставка';
$_['text_comparison_list']	= 'Сравнение товаров';
$_['text_shopping_cart']	= 'Ваша корзина';
$_['text_cat_says']			= 'Давай помогу тебе потратить деньги :)';
$_['text_product_removed']	= 'Товар удалён из корзины';
$_['text_cancel']			= 'Отмена';