<?php
$_['text_blog']				= 'Блог';
$_['text_contact']			= 'Контакти';
$_['text_about']			= 'За нас';
$_['text_delivery']			= 'Доставка';
$_['text_comparison_list']	= 'Сравнете продукти';
$_['text_shopping_cart']	= 'Вашата кошница';
$_['text_cat_says']			= 'Нека да ви помогна в избора на продукти :)';
$_['text_product_removed']	= 'Продуктът е изваден от кошницата';
$_['text_cancel']			= 'Отмени';