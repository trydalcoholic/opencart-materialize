<?php
// Heading
$_['heading_search']	= 'Пошук';
$_['heading_category']	= 'Категорії';
$_['heading_post']		= 'Останні пости';

// Text
$_['text_search']		= 'Пошук по блогу';