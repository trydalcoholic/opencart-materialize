<?php
// Text
$_['text_subject']		= '%s - Замовлення зворотного дзвінка';
$_['text_waiting']		= 'Очікування зворотного дзвінка.';
$_['text_telephone']	= 'Телефон: %s';
$_['text_name']			= 'Ім&#39;я: %s';
$_['text_enquiry']		= 'Коментар: %s';
$_['text_calltime']		= 'Зручний час дзвінка: %s';