<?php
// Text
$_['text_subject']		= '%s - Швидке замовлення';
$_['text_waiting']		= 'Очікування оформлення швидкого замовлення.';
$_['text_product']		= 'Товар: %s';
$_['text_link']			= 'Посилання: %s';
$_['text_telephone']	= 'Телефон: %s';
$_['text_name']			= 'Ім&#39;я: %s';
$_['text_email']		= 'E-mail: %s';
$_['text_enquiry']		= 'Коментар: %s';
$_['text_calltime']		= 'Зручний час дзвінка: %s';