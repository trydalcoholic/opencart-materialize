<?php
// PhotoSwipe
$_['button_share']					= 'Споделете';
$_['button_pswp_close']				= 'Затвори (Изход)';
$_['button_pswp_toggle_fullscreen']	= 'Превключване на цял екран';
$_['button_pswp_zoom']				= 'Увеличаване / намаляване на мащаба';
$_['button_pswp_prev']				= 'Предишна (стрелка наляво)';
$_['button_pswp_next']				= 'Следваща (стрелка надясно)';