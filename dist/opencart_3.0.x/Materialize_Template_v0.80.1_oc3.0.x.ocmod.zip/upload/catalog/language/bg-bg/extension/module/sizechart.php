<?php
// Text
$_['text_sizechart']	= 'Таблица Размери';