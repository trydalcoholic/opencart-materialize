<?php
// PhotoSwipe
$_['button_share']					= 'Paylaş';
$_['button_pswp_close']				= 'Kapat (Esc)';
$_['button_pswp_toggle_fullscreen']	= 'Tam ekran göster';
$_['button_pswp_zoom']				= 'Yakınlaştır / Uzaklaştır';
$_['button_pswp_prev']				= 'Önceki (sol ok)';
$_['button_pswp_next']				= 'Sonraki (sağ ok)';