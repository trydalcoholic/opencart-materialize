<?php
// PhotoSwipe
$_['button_share']					= 'Acțiune';
$_['button_pswp_close']				= 'Închide (Esc)';
$_['button_pswp_toggle_fullscreen']	= 'Comutare la ecran complet';
$_['button_pswp_zoom']				= 'Măriți / micșorați';
$_['button_pswp_prev']				= 'Înainte (săgeată stânga)';
$_['button_pswp_next']				= 'Înainte (dreapta pe săgeată)';