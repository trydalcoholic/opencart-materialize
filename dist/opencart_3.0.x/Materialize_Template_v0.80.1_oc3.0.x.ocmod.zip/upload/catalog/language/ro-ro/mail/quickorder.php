<?php
// Text
$_['text_subject']		= '%s - Comandă rapidă';
$_['text_waiting']		= 'Așteptând o comandă rapidă.';
$_['text_product']		= 'Produs: %s';
$_['text_link']			= 'Legătură: %s';
$_['text_telephone']	= 'Telefon: %s';
$_['text_name']			= 'Nume: %s';
$_['text_email']		= 'E-mail: %s';
$_['text_enquiry']		= 'Comentariu: %s';
$_['text_calltime']		= 'Timp convenabil pentru un apel: %s';