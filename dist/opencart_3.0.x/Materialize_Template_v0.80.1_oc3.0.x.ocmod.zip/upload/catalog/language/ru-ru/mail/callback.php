<?php
// Text
$_['text_subject']		= '%s - Заказ обратного звонка';
$_['text_waiting']		= 'Ожидание обратного звонка.';
$_['text_telephone']	= 'Телефон: %s';
$_['text_name']			= 'Имя: %s';
$_['text_enquiry']		= 'Комментарий: %s';
$_['text_calltime']		= 'Удобное время для звонка: %s';