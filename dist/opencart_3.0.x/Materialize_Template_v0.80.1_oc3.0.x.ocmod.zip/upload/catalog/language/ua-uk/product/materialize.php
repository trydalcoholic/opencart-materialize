<?php
$_['text_sku']						= 'Артикул';
$_['text_upc']						= 'UPC';
$_['text_ean']						= 'EAN';
$_['text_jan']						= 'JAN';
$_['text_isbn']						= 'ISBN';
$_['text_mpn']						= 'MPN';
$_['text_location']					= 'Розташування';
$_['text_dimension']				= 'Розміри (Д х Ш х В)';
$_['text_weight']					= 'Вага';
$_['text_remainder']				= 'Залишок';
$_['text_size_chart']				= 'Таблиця розмірів';
$_['text_category']					= 'Категорія';
$_['text_bonus_points']				= 'бонусних балів за покупку';
$_['text_end_promotion']			= 'Акція закінчиться';
$_['text_percent']					= 'Знижка';
$_['text_more_detailed']			= 'Детальніше';

// Product list
$_['text_searched']					= 'Ви шукали:';
$_['text_refine']					= 'Уточнити категорію';
$_['text_sort_short']				= 'Сортувати';
$_['entry_instock']					= 'Показувати тільки в наявності';
$_['text_manufacturers_starting']	= 'Всі виробники, що починаються на';
$_['text_view_all_products']		= 'Переглянути всі товари';