<?php
// Text
$_['text_sizechart']	= 'Size Chart';