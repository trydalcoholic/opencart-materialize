<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-tags"></i>&nbsp;&nbsp;&nbsp;Materialize "Labels"</b></font>';
$_['label_title']		= 'Materialize "Labels"';

// Text
$_['text_module']		= 'Modules';
$_['text_success']		= 'Module settings updated!';
$_['text_edit']			= 'Editing Materialize Labels';

// Entry
$_['entry_status']		= 'Status';

// Error
$_['error_permission']	= 'You do not have permission to manage this module!';