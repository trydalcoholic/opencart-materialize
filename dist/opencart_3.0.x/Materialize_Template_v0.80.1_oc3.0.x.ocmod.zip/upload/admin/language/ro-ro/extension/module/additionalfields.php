<?php
// Heading
$_['heading_title']				= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Câmpuri suplimentare</b></font>';
$_['additionalfields_title']	= 'Câmpuri suplimentare';

// Text
$_['text_module']				= 'Module';
$_['text_success']				= 'Setările modulelor au fost actualizate!';
$_['text_edit']					= 'Editarea câmpurilor suplimentare';

// Entry
$_['entry_status']				= 'Status';

// Error
$_['error_permission']			= 'Nu aveți permisiunea de a gestiona acest modul!';