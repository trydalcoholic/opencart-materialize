<?php
// Heading
$_['heading_title']			= '<font color="#263238"><b><i class="fa fa-phone"></i>&nbsp;&nbsp;&nbsp;Materialize "Call Back"</b></font>';
$_['callback_title']		= 'Materialize "Call Back"';

// Text
$_['text_extension']		= 'Extensii';
$_['text_success']			= 'Succes: Ați modificat tabloul de bord "Call Back"!';
$_['text_edit']				= 'Editați tabloul de bord "Call Back"';
$_['text_view']				= 'Afișați mai multe...';

// Entry
$_['entry_status']			= 'Stare';
$_['entry_sort_order']		= 'Sortați ordinea';
$_['entry_width']			= 'lățime';

// Error
$_['error_permission']		= 'Avertisment: Nu aveți permisiunea de a modifica tabloul de bord "Call Back"!';