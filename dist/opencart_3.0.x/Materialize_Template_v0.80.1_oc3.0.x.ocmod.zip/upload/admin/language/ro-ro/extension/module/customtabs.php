<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Tab-uri personalizate</b></font>';
$_['customtabs_title']	= 'Tab-uri personalizate';

// Text
$_['text_module']		= 'Module';
$_['text_success']		= 'Setările modulelor au fost actualizate!';
$_['text_edit']			= 'Editarea filelor personalizate';

// Entry
$_['entry_status']		= 'Status';

// Error
$_['error_permission']	= 'Nu aveți permisiunea de a gestiona acest modul!';