<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-table"></i>&nbsp;&nbsp;&nbsp;Materialize "Таблица Размери"</b></font>';
$_['sizechart_title']	= 'Materialize "Таблица Размери"';

// Text
$_['text_module']		= 'Модули';
$_['text_success']		= 'Настройките на модула са обновени!';
$_['text_edit']			= 'Редактиране на Materialize Таблица Размери';

// Entry
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'Нямате разрешение да управлявате този модул!';