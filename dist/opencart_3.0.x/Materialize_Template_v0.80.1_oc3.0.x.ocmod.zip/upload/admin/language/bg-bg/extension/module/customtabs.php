<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Персонализирани Раздели</b></font>';
$_['customtabs_title']	= 'Персонализирани Раздели';

// Text
$_['text_module']		= 'Модули';
$_['text_success']		= 'Настройките на модула са обновени!';
$_['text_edit']			= 'Редактиране на Персонализирани Раздели';

// Entry
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'Нямате разрешение да управлявате този модул!';