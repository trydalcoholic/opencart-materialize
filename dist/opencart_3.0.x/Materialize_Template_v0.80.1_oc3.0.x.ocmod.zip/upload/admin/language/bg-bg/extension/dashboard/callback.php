<?php
// Heading
$_['heading_title']			= '<font color="#263238"><b><i class="fa fa-phone"></i>&nbsp;&nbsp;&nbsp;Materialize "Позванете обратно"</b></font>';
$_['callback_title']		= 'Materialize "Позванете обратно"';

// Text
$_['text_extension']		= 'Разширения';
$_['text_success']			= 'Успех: Променихте таблото "Позванете обратно"!';
$_['text_edit']				= 'Редактиране на таблото "Позванете обратно"';
$_['text_view']				= 'Виж повече...';

// Entry
$_['entry_status']			= 'Статус';
$_['entry_sort_order']		= 'Сортиране';
$_['entry_width']			= 'Дължина';

// Error
$_['error_permission']		= 'Warning: Нямате разрешение да променяте таблото "Позванете обратно"!';