<?php
$_['text_view_map']	= 'Vizualizați pe hartă';