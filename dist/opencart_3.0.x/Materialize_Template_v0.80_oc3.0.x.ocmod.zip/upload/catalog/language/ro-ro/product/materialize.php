<?php
$_['text_sku']						= 'SKU';
$_['text_upc']						= 'UPC';
$_['text_ean']						= 'EAN';
$_['text_jan']						= 'JAN';
$_['text_isbn']						= 'ISBN';
$_['text_mpn']						= 'MPN';
$_['text_location']					= 'Locație';
$_['text_dimension']				= 'Dimensiuni (L x W x H)';
$_['text_weight']					= 'Greutate';
$_['text_remainder']				= 'Rest';
$_['text_size_chart']				= 'Tabel cu marimi';
$_['text_category']					= 'Categorie';
$_['text_bonus_points']				= 'puncte bonus la cumparare';
$_['text_end_promotion']			= 'Oferta expira pe';
$_['text_percent']					= 'Discount';
$_['text_more_detailed']			= 'Mai multe detalii';

// Product list
$_['text_searched']					= 'Ai cautat:';
$_['text_refine']					= 'Defineste categoria';
$_['text_sort_short']				= 'Sorteaza';
$_['entry_instock']					= 'Arata doar in stoc';
$_['text_manufacturers_starting']	= 'Toti producatorii cu';
$_['text_view_all_products']		= 'Vezi toate produsele';