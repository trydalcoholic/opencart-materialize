<?php
// Text
$_['text_sizechart']	= 'Tabel cu marimi';