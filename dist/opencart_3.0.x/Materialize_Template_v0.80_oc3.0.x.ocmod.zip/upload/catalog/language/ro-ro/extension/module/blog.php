<?php
// Heading
$_['heading_search']	= 'Căutare';
$_['heading_category']	= 'Categorii';
$_['heading_post']		= 'Postări recente';

// Text
$_['text_search']		= 'Blogul de căutare';