<?php
// Text
$_['text_subject']		= '%s - Comanda solicitare contact';
$_['text_waiting']		= 'Asteapta un telefon.';
$_['text_telephone']	= 'Telefon: %s';
$_['text_name']			= 'Nume: %s';
$_['text_enquiry']		= 'Comentariu: %s';
$_['text_calltime']		= 'Timp convenabil pentru un apel: %s';