<?php
$_['text_blog']				= 'Блог';
$_['text_contact']			= 'Контакти';
$_['text_about']			= 'Про нас';
$_['text_delivery']			= 'Доставка';
$_['text_comparison_list']	= 'Порівняння товарів';
$_['text_shopping_cart']	= 'Ваша корзина';
$_['text_cat_says']			= 'Давай допоможу тобі витратити гроші :)';
$_['text_product_removed']	= 'Товар вилучений з кошика';
$_['text_cancel']			= 'Відміна';