<?php
// PhotoSwipe
$_['button_share']					= 'Поділитися';
$_['button_pswp_close']				= 'Закрити (Esc)';
$_['button_pswp_toggle_fullscreen']	= 'Включити повноекранний режим';
$_['button_pswp_zoom']				= 'Збільшити/зменшити';
$_['button_pswp_prev']				= 'Попередня (стрілка вліво)';
$_['button_pswp_next']				= 'Наступна (стрілка вправо)';