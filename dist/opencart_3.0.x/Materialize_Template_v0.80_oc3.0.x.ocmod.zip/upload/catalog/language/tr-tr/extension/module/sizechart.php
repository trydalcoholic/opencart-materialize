<?php
// Text
$_['text_sizechart']	= 'Beden tablosu';