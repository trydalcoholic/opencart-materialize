<?php
// Heading
$_['heading_search']	= 'Ara';
$_['heading_category']	= 'Kategoriler';
$_['heading_post']		= 'Yakın Zamanda Gönderilenler';

// Text
$_['text_search']		= 'Blogda Ara';