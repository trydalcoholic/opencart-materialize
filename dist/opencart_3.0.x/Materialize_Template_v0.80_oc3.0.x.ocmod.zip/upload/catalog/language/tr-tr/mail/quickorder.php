<?php
// Text
$_['text_subject']		= '%s - Hızlı sipariş';
$_['text_waiting']		= 'Hızlı bir sipariş bekleniyor.';
$_['text_product']		= 'Ürün: %s';
$_['text_link']			= 'Bağlantı: %s';
$_['text_telephone']	= 'Telefon: %s';
$_['text_name']			= 'İsim: %s';
$_['text_email']		= 'E-posta: %s';
$_['text_enquiry']		= 'Yorum Yap: %s';
$_['text_calltime']		= 'Bir görüşme yapmak için uygun zaman: %s';