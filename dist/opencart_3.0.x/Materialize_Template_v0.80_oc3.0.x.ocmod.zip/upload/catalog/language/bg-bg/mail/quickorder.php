<?php
// Text
$_['text_subject']		= '%s - Бърза поръчка';
$_['text_waiting']		= 'Очакване за Бърза поръчка.';
$_['text_product']		= 'Продукт: %s';
$_['text_link']			= 'Линк: %s';
$_['text_telephone']	= 'Телефон: %s';
$_['text_name']			= 'Име: %s';
$_['text_email']		= 'Имейл: %s';
$_['text_enquiry']		= 'Коментар: %s';
$_['text_calltime']		= 'Удобно време за разговор: %s';