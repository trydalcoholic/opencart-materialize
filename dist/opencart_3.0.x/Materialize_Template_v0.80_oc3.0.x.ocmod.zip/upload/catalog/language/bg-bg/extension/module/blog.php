<?php
// Heading
$_['heading_search']	= 'Търсене';
$_['heading_category']	= 'Категории';
$_['heading_post']		= 'Нови публикации';

// Text
$_['text_search']		= 'Търсене в Блога';