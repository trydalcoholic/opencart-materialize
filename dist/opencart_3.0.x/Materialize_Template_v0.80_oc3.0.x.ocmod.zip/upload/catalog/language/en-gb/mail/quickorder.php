<?php
// Text
$_['text_subject']		= '%s - Quick order';
$_['text_waiting']		= 'Waiting for a quick order.';
$_['text_product']		= 'Product: %s';
$_['text_link']			= 'Link: %s';
$_['text_telephone']	= 'Phone: %s';
$_['text_name']			= 'Name: %s';
$_['text_email']		= 'E-mail: %s';
$_['text_enquiry']		= 'Comment: %s';
$_['text_calltime']		= 'Convenient time for a call: %s';