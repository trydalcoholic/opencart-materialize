<?php
// Text
$_['text_subject']		= '%s - Быстрый заказ';
$_['text_waiting']		= 'Ожидание оформления быстрого заказа.';
$_['text_product']		= 'Товар: %s';
$_['text_link']			= 'Ссылка: %s';
$_['text_telephone']	= 'Телефон: %s';
$_['text_name']			= 'Имя: %s';
$_['text_email']		= 'E-mail: %s';
$_['text_enquiry']		= 'Комментарий: %s';
$_['text_calltime']		= 'Удобное время для звонка: %s';