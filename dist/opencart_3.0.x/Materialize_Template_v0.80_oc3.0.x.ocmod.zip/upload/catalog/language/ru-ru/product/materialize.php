<?php
$_['text_sku']						= 'Артикул';
$_['text_upc']						= 'UPC';
$_['text_ean']						= 'EAN';
$_['text_jan']						= 'JAN';
$_['text_isbn']						= 'ISBN';
$_['text_mpn']						= 'MPN';
$_['text_location']					= 'Расположение';
$_['text_dimension']				= 'Размеры (Д х Ш х В)';
$_['text_weight']					= 'Вес';
$_['text_remainder']				= 'Остаток';
$_['text_size_chart']				= 'Таблица размеров';
$_['text_category']					= 'Категория';
$_['text_bonus_points']				= 'бонусных баллов за покупку';
$_['text_end_promotion']			= 'Акция закончится';
$_['text_percent']					= 'Скидка';
$_['text_more_detailed']			= 'Подробнее';

// Product list
$_['text_searched']					= 'Вы искали:';
$_['text_refine']					= 'Уточнить категорию';
$_['text_sort_short']				= 'Сортировать';
$_['entry_instock']					= 'Показывать только в наличии';
$_['text_manufacturers_starting']	= 'Все производители, начинающиеся на';
$_['text_view_all_products']		= 'Посмотреть все товары';