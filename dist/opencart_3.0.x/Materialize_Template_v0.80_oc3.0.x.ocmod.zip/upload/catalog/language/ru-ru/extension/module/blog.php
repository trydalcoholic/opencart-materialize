<?php
// Heading
$_['heading_search']	= 'Поиск';
$_['heading_category']	= 'Категории';
$_['heading_post']		= 'Последние посты';

// Text
$_['text_search']		= 'Поиск по блогу';