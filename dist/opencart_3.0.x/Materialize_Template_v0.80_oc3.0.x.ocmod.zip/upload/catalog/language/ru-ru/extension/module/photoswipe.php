<?php
// PhotoSwipe
$_['button_share']					= 'Поделиться';
$_['button_pswp_close']				= 'Закрыть (Esc)';
$_['button_pswp_toggle_fullscreen']	= 'Включить полноэкранный режим';
$_['button_pswp_zoom']				= 'Увеличить/уменьшить';
$_['button_pswp_prev']				= 'Предыдущая (стрелка влево)';
$_['button_pswp_next']				= 'Следующая (стрелка вправо)';