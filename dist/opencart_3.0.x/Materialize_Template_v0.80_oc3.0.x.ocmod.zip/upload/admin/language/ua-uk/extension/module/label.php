<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-tags"></i>&nbsp;&nbsp;&nbsp;Materialize "Етикетки"</b></font>';
$_['label_title']		= 'Materialize "Етикетки"';

// Text
$_['text_module']		= 'Модулі';
$_['text_success']		= 'Налаштування модуля оновлено!';
$_['text_edit']			= 'Редагування Materialize Етикетки';

// Status
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'У вас немає прав для управління модулем!';