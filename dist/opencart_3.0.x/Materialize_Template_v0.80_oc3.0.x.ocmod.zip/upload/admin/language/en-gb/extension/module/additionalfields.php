<?php
// Heading
$_['heading_title']				= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Additional Fields</b></font>';
$_['additionalfields_title']	= 'Additional Fields';

// Text
$_['text_module']				= 'Modules';
$_['text_success']				= 'Module settings updated!';
$_['text_edit']					= 'Editing Additional Fields';

// Entry
$_['entry_status']				= 'Status';

// Error
$_['error_permission']			= 'You do not have permission to manage this module!';