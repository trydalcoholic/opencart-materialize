<?php
// Heading
$_['heading_title']			= '<font color="#263238"><b><i class="fa fa-phone"></i>&nbsp;&nbsp;&nbsp;Materialize "Call Back"</b></font>';
$_['callback_title']		= 'Materialize "Call Back"';

// Text
$_['text_extension']		= 'Extensions';
$_['text_success']			= 'Success: You have modified dashboard "Call Back"!';
$_['text_edit']				= 'Edit Dashboard "Call Back"';
$_['text_view']				= 'View more...';

// Entry
$_['entry_status']			= 'Status';
$_['entry_sort_order']		= 'Sort Order';
$_['entry_width']			= 'Width';

// Error
$_['error_permission']		= 'Warning: You do not have permission to modify dashboard "Call Back"!';