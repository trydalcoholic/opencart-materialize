<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Özel Sekmeler</b></font>';
$_['customtabs_title']	= 'Özel Sekmeler';

// Text
$_['text_module']		= 'Modüller';
$_['text_success']		= 'Modül ayarları güncellendi!';
$_['text_edit']			= 'Özel Sekmeleri Düzenleme';

// Entry
$_['entry_status']		= 'Durum';

// Error
$_['error_permission']	= 'Bu modül yönetmek için izniniz yok!';