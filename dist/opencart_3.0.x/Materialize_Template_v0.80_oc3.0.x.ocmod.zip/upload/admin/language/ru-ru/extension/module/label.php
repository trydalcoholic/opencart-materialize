<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-tags"></i>&nbsp;&nbsp;&nbsp;Materialize "Этикетки"</b></font>';
$_['label_title']		= 'Materialize "Этикетки"';

// Text
$_['text_module']		= 'Модули';
$_['text_success']		= 'Настройки модуля обновлены!';
$_['text_edit']			= 'Редактирование Materialize Этикетки';

// Status
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'У вас нет прав для управления модулем!';