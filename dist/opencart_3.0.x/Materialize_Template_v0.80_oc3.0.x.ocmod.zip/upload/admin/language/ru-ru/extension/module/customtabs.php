<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-plus"></i>&nbsp;&nbsp;&nbsp;Дополнительные вкладки</b></font>';
$_['customtabs_title']	= 'Дополнительные вкладки';

// Text
$_['text_module']		= 'Модули';
$_['text_success']		= 'Настройки модуля обновлены!';
$_['text_edit']			= 'Редактирование Дополнительных вкладок';

// Entry
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'У вас нет прав для управления модулем!';