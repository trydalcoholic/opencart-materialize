<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-table"></i>&nbsp;&nbsp;&nbsp;Materialize "Таблица размеров"</b></font>';
$_['sizechart_title']	= 'Materialize "Таблица размеров"';

// Text
$_['text_module']		= 'Модули';
$_['text_success']		= 'Настройки модуля обновлены!';
$_['text_edit']			= 'Редактирование Materialize Таблица размеров';

// Entry
$_['entry_status']		= 'Статус';

// Error
$_['error_permission']	= 'У вас нет прав для управления модулем!';