<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-tags"></i>&nbsp;&nbsp;&nbsp;Materialize "Etiketler"</b></font>';
$_['label_title']		= 'Materialize "Etiketler"';

// Text
$_['text_module']		= 'Modules';
$_['text_success']		= 'Module settings updated!';
$_['text_edit']			= 'Düzenle Materialize Etiketler';

// Status
$_['entry_status']		= 'Durum';

// Error
$_['error_permission']	= 'Bu modül yönetmek için izniniz yok!';