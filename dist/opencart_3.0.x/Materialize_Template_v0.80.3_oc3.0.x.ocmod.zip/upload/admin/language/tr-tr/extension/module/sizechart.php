<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-table"></i>&nbsp;&nbsp;&nbsp;Materialize "Beden Tablosu"</b></font>';
$_['sizechart_title']	= 'Materialize "Beden tablosu"';

// Text
$_['text_module']		= 'Modüller';
$_['text_success']		= 'Modül ayarları güncellendi!';
$_['text_edit']			= 'Materialize Beden tablosu modülünü düzenle';

// Status
$_['entry_status']		= 'Durum';

// Error
$_['error_permission']	= 'Bu modül yönetmek için izniniz yok!';