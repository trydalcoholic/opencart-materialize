<?php
// Heading
$_['heading_title']		= '<font color="#263238"><b><i class="fa fa-tags"></i>&nbsp;&nbsp;&nbsp;Materialize "Etichete"</b></font>';
$_['label_title']		= 'Materialize "Etichete"';

// Text
$_['text_module']		= 'Module';
$_['text_success']		= 'Setările modulelor au fost actualizate!';
$_['text_edit']			= 'Editarea Materialize Etichete';

// Status
$_['entry_status']		= 'Status';

// Error
$_['error_permission']	= 'Nu aveți permisiunea de a gestiona acest modul!';