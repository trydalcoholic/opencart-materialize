<?php
$_['text_sku']						= 'SKU';
$_['text_upc']						= 'UPC';
$_['text_ean']						= 'EAN';
$_['text_jan']						= 'JAN';
$_['text_isbn']						= 'ISBN';
$_['text_mpn']						= 'MPN';
$_['text_location']					= 'Yer';
$_['text_dimension']				= 'Boyutları (U x G x Y)';
$_['text_weight']					= 'Ağırlık';
$_['text_remainder']				= 'Kalan';
$_['text_size_chart']				= 'Beden tablosu';
$_['text_category']					= 'Kategori';
$_['text_bonus_points']				= 'Satın almak için bonus puan';
$_['text_end_promotion']			= 'Teklif sone erme zamanı';
$_['text_percent']					= 'İndirim';
$_['text_more_detailed']			= 'Ayrıntılı göster';

// Product list
$_['text_searched']					= 'Arama nedeniniz:';
$_['text_refine']					= 'Kategoriyi filtrele';
$_['text_sort_short']				= 'Tür';
$_['entry_instock']					= 'Sadece stoklarda göster';
$_['text_manufacturers_starting']	= 'Tüm üreticiler başlangıcı';
$_['text_view_all_products']		= 'Tüm ürünleri görüntüle';