<?php
$_['text_blog']				= 'Blog';
$_['text_contact']			= 'Contact';
$_['text_about']			= 'Despre noi';
$_['text_delivery']			= 'Livrare';
$_['text_comparison_list']	= 'Lista comparare';
$_['text_shopping_cart']	= 'Cos de cumparaturi';
$_['text_cat_says']			= 'Te ajut sa iti cheltuiesti banii :)';
$_['text_product_removed']	= 'Articol eliminat din cărucior';
$_['text_cancel']			= 'Anulare';