<?php
// Text
$_['text_subject']		= '%s - Call Back order';
$_['text_waiting']		= 'Call Waiting.';
$_['text_telephone']	= 'Phone: %s';
$_['text_name']			= 'Name: %s';
$_['text_enquiry']		= 'Comment: %s';
$_['text_calltime']		= 'Convenient time for a call: %s';