<?php
$_['text_blog']				= 'Blog';
$_['text_contact']			= 'Contact Us';
$_['text_about']			= 'About';
$_['text_delivery']			= 'Delivery';
$_['text_comparison_list']	= 'Compare products';
$_['text_shopping_cart']	= 'Your shopping cart';
$_['text_cat_says']			= 'Let me help you spend some money :)';
$_['text_product_removed']	= 'Item removed from cart';
$_['text_cancel']			= 'Cancel';