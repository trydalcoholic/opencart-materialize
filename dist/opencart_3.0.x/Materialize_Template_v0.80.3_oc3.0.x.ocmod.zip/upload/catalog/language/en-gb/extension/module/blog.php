<?php
// Heading
$_['heading_search']	= 'Search';
$_['heading_category']	= 'Categories';
$_['heading_post']		= 'Recent Posts';

// Text
$_['text_search']		= 'Search Blog';