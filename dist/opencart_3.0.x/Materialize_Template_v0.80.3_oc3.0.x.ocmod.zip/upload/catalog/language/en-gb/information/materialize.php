<?php
$_['text_view_map']	= 'View on map';