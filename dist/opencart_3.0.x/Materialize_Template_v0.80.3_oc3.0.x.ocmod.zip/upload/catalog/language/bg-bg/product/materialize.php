<?php
$_['text_sku']						= 'SKU';
$_['text_upc']						= 'UPC';
$_['text_ean']						= 'EAN';
$_['text_jan']						= 'JAN';
$_['text_isbn']						= 'ISBN';
$_['text_mpn']						= 'MPN';
$_['text_location']					= 'Местоположение';
$_['text_dimension']				= 'Размери (L x W x H)';
$_['text_weight']					= 'Тегло';
$_['text_remainder']				= 'Остатък';
$_['text_size_chart']				= 'Таблица Размери';
$_['text_category']					= 'Категория';
$_['text_bonus_points']				= 'бонус точки за покупка';
$_['text_end_promotion']			= 'Офертата ще изтече на';
$_['text_percent']					= 'Oтстъпка';
$_['text_more_detailed']			= 'Повече инфо';

// Product list
$_['text_searched']					= 'Търсихте:';
$_['text_refine']					= 'Прецизирайте категорията';
$_['text_sort_short']				= 'Сортиране';
$_['entry_instock']					= 'Показване само на склад';
$_['text_manufacturers_starting']	= 'Всички производители започващи с';
$_['text_view_all_products']		= 'Преглед на всички продукти';