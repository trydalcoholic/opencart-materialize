<?php
$_['text_view_map']	= 'Подивитися на карті';